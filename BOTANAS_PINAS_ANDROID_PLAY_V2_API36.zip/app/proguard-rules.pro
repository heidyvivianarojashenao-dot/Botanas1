# Botanas Piña's app rules. No custom shrinking rules are required yet.
