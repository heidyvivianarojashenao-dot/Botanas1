# BOTANAS PIÑA — Android / Google Play

Proyecto preparado a partir de la V33, manteniendo la aplicación web dentro del APK/AAB para que el funcionamiento diario no dependa de Netlify ni de créditos de hosting.

## Estado técnico
- compileSdk: 36
- targetSdk: 36
- minSdk: 23
- applicationId: com.botanaspinas.app
- versionCode: 1
- versionName: 1.0.0
- Sin permisos de Internet ni notificaciones solicitados por la app base.
- Los archivos HTML/JS/imágenes de V33 van dentro de `app/src/main/assets/`.

## Para Google Play
1. Una persona adulta que cumpla los requisitos de Google debe crear/verificar la cuenta de Play Console.
2. Completar la configuración de la aplicación en Play Console.
3. Generar un Android App Bundle firmado (`.aab`).
4. Completar la ficha: nombre, descripción, icono, capturas, categoría, contacto, privacidad y clasificación de contenido.
5. Si la cuenta personal es nueva y está sujeta al requisito de pruebas, realizar la prueba cerrada exigida por Google antes de solicitar producción.
6. Solicitar acceso a producción y enviar la versión para revisión.

## Importante
Google Play exige que las apps nuevas enviadas desde el 31 de agosto de 2026 tengan como objetivo Android 16 / API 36 o posterior. Este proyecto ya está preparado con targetSdk 36.

## Compilación desde celular
Este proyecto está pensado para poder llevarse a un entorno Android/Gradle en la nube desde el navegador del celular. La firma final debe conservarse de forma segura y no compartirse públicamente.
